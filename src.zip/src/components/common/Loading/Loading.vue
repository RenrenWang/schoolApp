<template>
  <div id="loading" v-show="isShow">
        <p>{{msg}}</p>     
 </div>
</template>

<script>
export default {
  name: 'loading',
  props:["msg","isShow"],
  data () {
    return {
    
    }
  }
}
</script>
<style scoped lang="scss">
@import "../../../assets/style/base.scss";
 #loading{
     height:rem(60px);
     line-height:rem(60px);
     alignItems:center;
     justify-content:center;
   
     font-size:16px;
     text-align:center;
 }
</style>